//
//  ImageStore.swift
//  UsedGames
//
//  Created by Can Küçükcanbaz on 12.05.2024.
//

import UIKit


class ImageStore: ObservableObject{
    
    let cache = NSCache<NSString, UIImage>()
    
    func setImage(_ image: UIImage, forKey key: String){
        cache.setObject(image, forKey: key as NSString)
        objectWillChange.send()
    }
    
    func image(forKey key: String) -> UIImage?{
        return cache.object(forKey: key as NSString)
    }
    
    func deleteImage(forKey key: String){
        cache.removeObject(forKey: key as NSString)
        objectWillChange.send()
    }
}
