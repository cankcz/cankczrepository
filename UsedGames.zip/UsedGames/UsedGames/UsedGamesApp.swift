//
//  UsedGamesApp.swift
//  UsedGames
//
//  Created by Can Küçükcanbaz on 15.08.2023.
//

import SwiftUI

@main
struct UsedGamesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
