//
//  PhotoPicker.swift
//  UsedGames
//
//  Created by Can Küçükcanbaz on 11.05.2024.
//

import UIKit
import SwiftUI

struct PhotoPicker: UIViewControllerRepresentable{
    var sourceType: UIImagePickerController.SourceType = .photoLibrary
    var imageStore: ImageStore
    var game: Game
    @Binding var selectedPhoto: UIImage?
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<PhotoPicker>) -> some UIViewController {
        
        let pickerController = UIImagePickerController()
        pickerController.allowsEditing = true
        pickerController.sourceType = sourceType
        pickerController.delegate = context.coordinator
        return pickerController
    }
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(withPicker: self)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
        
        var photoPicker: PhotoPicker
        
        init(withPicker picker: PhotoPicker){
            
            self.photoPicker = picker
            super.init()
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            
            if let selectedPhoto = info[.editedImage] as? UIImage ?? info[.originalImage] as? UIImage {
                photoPicker.selectedPhoto = selectedPhoto
                photoPicker.imageStore.setImage(selectedPhoto, forKey: photoPicker.game.itemKey)
            }else{
                photoPicker.selectedPhoto = nil
            }
            
            picker.dismiss(animated: true, completion: nil)
        }
        
    }
}
