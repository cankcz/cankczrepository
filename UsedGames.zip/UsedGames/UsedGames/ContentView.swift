//
//  ContentView.swift
//  UsedGames
//
//  Created by Can Küçükcanbaz on 15.08.2023.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var gameStore = GameStore()
    @ObservedObject var imageStore = ImageStore()
    
    @State var gameToDelete: Game?
    
    var body: some View {
        NavigationView {
            List {
                ForEach(gameStore.games) { game in
                    NavigationLink(destination: DetailView(game: game, gameStore: gameStore,imageStore: imageStore, name: game.name,price:game.priceInDollars,selectedPhoto: imageStore.image(forKey: game.itemKey))) {
                        GameListItem(game: game)
                    }
                }
                .onDelete { indexSet in
                    let gameToDelete = gameStore.game(at: indexSet)
                    self.gameToDelete = gameToDelete
                    if let gameToDelete = gameToDelete{
                        self.imageStore.deleteImage(forKey: gameToDelete.itemKey)
                    }
                    
                    
                }
                .onMove { indices, newOffset in
                    gameStore.move(indices: indices, to: newOffset)
                }
            }
            .animation(.easeIn)
            .overlay(
                VStack {
                    HStack {
                        EditButton()
                        Spacer()
                        Button(action: { gameStore.creatGame() }) {
                            Text("Add")
                        }
                        .buttonStyle(BorderedButtonStyle())
                    }
                    .padding()
                    .background(Color(UIColor.systemBackground).edgesIgnoringSafeArea(.top))
                    Spacer()
                }
            )
            .actionSheet(item: $gameToDelete) { game in
                ActionSheet(
                    title: Text("Are you sure?"),
                    message: Text("You will delete \(game.name)"),
                    buttons: [
                        .cancel(),
                        .destructive(Text("Delete")) {
                            if let indexSet = gameStore.indexSet(for: game) {
                                gameStore.delete(at: indexSet)
                            }
                        }
                    ]
                )
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



