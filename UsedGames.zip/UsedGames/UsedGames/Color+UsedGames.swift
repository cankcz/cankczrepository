//
//  Color+UsedGames.swift
//  UsedGames
//
//  Created by Can Küçükcanbaz on 20.09.2023.
//

import SwiftUI

extension Color{
    
  private  static var usedGamesWhite: Color{
        return Color("UsedGamesWhite")
    }
    static var barBackgroundColor: Color{
        
        return usedGamesWhite
    }
}
